# Forskrift að útliti

## Form

![](frontpage.png)

## Form með villum

![](form-errors.png)

## Form með villum

![](form-errors2.png)

## Þakkarsíða

![](thanks.png)

## Innskráning

![](login.png)

## Form með upplýsingum um innskráðan notanda

![](frontpage-login.png)

## Stjórnunarsíða

![](admin.png)
